# RoboSoccer RC Wokwi Lab — Android project

This is an Android Studio project wrapping the existing simulator HTML/JavaScript in an Android WebView. It includes the simulator's local CSS and JavaScript, enables persistent `localStorage` for saved sketches, and routes `.ino` / `diagram.json` exports into `Downloads/RoboSoccer RC Lab/` using Android's MediaStore API.

## Build the APK

1. Install **Android Studio** (current stable) on Windows, macOS or Linux.
2. Open this folder (`RoboSoccer_Android_App`) in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio writes the debug APK to `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer that APK to your Android phone and install it. If Android asks, allow installing unknown apps for the file manager/browser used.

## Included app functionality

- Original simulator views, circuit/arena/split preview, and responsive controls
- FlySky FS-i6S six-channel virtual transmitter controls
- RoboSoccer, RC car, tank, airplane, boat and blank presets
- ESP32 sketch editor, customize mode, virtual compile/run/stop/reset
- BTS7960/motor visualization, telemetry and virtual Serial Monitor
- Saved sketches persist using WebView DOM storage
- Export `.ino` and `diagram.json` files to the Android Downloads folder

## Important limits

This APK wrapper runs the supplied simulator's existing virtual JavaScript behavior. It is not a Wokwi engine and does not provide physical FlySky receiver pairing, USB/OTG ESP32 serial communication, or native Arduino/ESP-IDF compilation. Those need separate hardware and integration work.

## Project details

- Package: `com.robosoccer.rclab`
- Minimum Android: 10 (API 29)
- Target / Compile SDK: 35
- Version: 1.0.0
