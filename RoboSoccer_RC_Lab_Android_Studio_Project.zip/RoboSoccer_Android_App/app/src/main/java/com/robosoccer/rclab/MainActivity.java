package com.robosoccer.rclab;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private WebView webView;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(11,15,23));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(8,12,18));
        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(11,15,23));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        webView.addJavascriptInterface(new AndroidBridge(this), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        if (state == null) webView.loadUrl("file:///android_asset/index.html");
        else webView.restoreState(state);
    }

    @Override protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (webView != null) webView.saveState(out);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    public static class AndroidBridge {
        private final Context context;
        AndroidBridge(Context context) { this.context = context; }

        @JavascriptInterface public void saveFile(String name, String content, String mime) {
            ((Activity)context).runOnUiThread(() -> {
                OutputStream out = null;
                try {
                    String safeName = name == null ? "export.txt" : name.replace('/', '_').replace('\\', '_');
                    String type = (mime == null || mime.isEmpty()) ? "text/plain" : mime.split(";")[0];
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                    values.put(MediaStore.Downloads.MIME_TYPE, type);
                    values.put(MediaStore.Downloads.RELATIVE_PATH, "Download/RoboSoccer RC Lab");
                    Uri uri = context.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new Exception("Could not create download file");
                    out = context.getContentResolver().openOutputStream(uri);
                    if (out == null) throw new Exception("Could not open download file");
                    out.write(content.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                    out.flush();
                    Toast.makeText(context, "Saved to Downloads/RoboSoccer RC Lab/" + safeName, Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(context, "Export failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                } finally {
                    try { if (out != null) out.close(); } catch (Exception ignored) {}
                }
            });
        }

        @JavascriptInterface public void copyText(String text) {
            ((Activity)context).runOnUiThread(() -> {
                android.content.ClipboardManager clipboard = (android.content.ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("RoboSoccer", text));
                Toast.makeText(context, "Copied to clipboard", Toast.LENGTH_SHORT).show();
            });
        }
    }
}
